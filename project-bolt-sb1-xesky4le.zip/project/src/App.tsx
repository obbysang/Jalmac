import React from 'react';
import { Sprout, ChevronRight, Facebook, Twitter, Linkedin, Instagram, Youtube, Globe } from 'lucide-react';
import { cn } from './lib/utils';

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="container mx-auto px-4 py-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sprout className="h-8 w-8 text-green-600" />
          <span className="text-xl font-bold">Jalmac</span>
        </div>
        <div className="flex items-center gap-6">
          <a href="#" className="text-gray-600 hover:text-green-600 transition-colors">Products</a>
          <a href="#" className="text-gray-600 hover:text-green-600 transition-colors">Pricing</a>
          <a href="#" className="text-gray-600 hover:text-green-600 transition-colors">Faqs</a>
          <a href="#" className="text-gray-600 hover:text-green-600 transition-colors">Our projects</a>
          <a href="#" className="text-gray-600 hover:text-green-600 transition-colors">Our mission</a>
          <a href="#" className="text-gray-600 hover:text-green-600 transition-colors">Our articles</a>
          <button className={cn(
            "px-4 py-2 bg-green-500 text-white rounded-lg",
            "hover:bg-green-600 transition-colors"
          )}>
            Log in to FarmCloud™
          </button>
          <button className={cn(
            "px-4 py-2 bg-green-500 text-white rounded-lg",
            "hover:bg-green-600 transition-colors"
          )}>
            Talk to a Consultant
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-b from-green-50 to-white py-20">
        <div className="container mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl font-bold mb-6">
              Building Hardware<br />
              and Software Tools<br />
              for <span className="text-green-500">Farmers in Africa</span>
            </h1>
            <p className="text-gray-700 mb-8">
              Jalmac provides an ecosystem of Smart Greenhouses and Solar Dryers equipped with <span className="text-orange-500">FarmShield™</span> IoT sensors connected to our <span className="text-blue-500">FarmCloud™</span> software enabling farmers to double incomes on less land, use less water, reduce post harvest losses and access premium markets.
            </p>
            <div className="flex gap-4">
              <button className={cn(
                "px-6 py-3 bg-green-500 text-white rounded-lg",
                "hover:bg-green-600 transition-colors"
              )}>
                Sign up to FarmCloud™
              </button>
              <button className={cn(
                "px-6 py-3 bg-green-500 text-white rounded-lg",
                "hover:bg-green-600 transition-colors"
              )}>
                Talk to a Consultant
              </button>
            </div>
          </div>
          <div>
            <img 
              src="https://images.unsplash.com/photo-1605000797499-95a51c5269ae"
              alt="Farmer using FarmCloud app"
              className="rounded-3xl shadow-xl w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Mission Statement */}
        <div className="container mx-auto px-4 max-w-4xl text-center mt-20">
          <p className="text-gray-800 text-lg mb-6">
            Today, over 21,000 farmers across Africa use our solutions to lower climate risks, eliminate guesswork in farming and earn better. We believe that farming should not be risky and complicated. It should be simple.
          </p>
          <p className="text-gray-800 text-lg mb-8">
            That's why we have partnered with leading organisations and funders to ensure we bring modern farming solutions to 1,000,000 smallholder farmers across Africa.
          </p>
          <a href="#" className="text-green-500 hover:text-green-600 inline-flex items-center transition-colors">
            Explore Synnefa's Mission <ChevronRight className="h-4 w-4 ml-1" />
          </a>
        </div>

        {/* Product Statement */}
        <div className="container mx-auto px-4 text-center mt-20">
          <h2 className="text-3xl font-bold mb-8">
            We install Greenhouses for crops or drying, fit <span className="text-green-500">Farm</span><span className="text-orange-500">Shield</span>™ IoT Sensors to optimise irrigation then connect it to <span className="text-green-500">Farm</span><span className="text-blue-500">Cloud</span>™ to track harvests & link farmers to markets!
          </h2>
        </div>
      </section>

      {/* Smart Greenhouse Section */}
      <section className="bg-green-50 py-20">
        <div className="container mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-bold mb-6">
              Protect your farm and<br />
              increase your Crop yield<br />
              with a Smart Greenhouse
            </h2>
            <p className="text-gray-700 mb-8">
              Receiving a Synnefa smart greenhouse is a partnership to ensure we provide farming solutions that are aimed at enhancing your ability to succeed and grow. When you grow, you buy more greenhouses from us and we grow together.
            </p>
            <div className="flex gap-4">
              <button className={cn(
                "px-6 py-3 bg-green-500 text-white rounded-lg",
                "hover:bg-green-600 transition-colors"
              )}>
                Learn more
              </button>
              <a href="#" className="text-green-500 hover:text-green-600 inline-flex items-center transition-colors">
                Get a price estimate <ChevronRight className="h-4 w-4 ml-1" />
              </a>
            </div>
          </div>
          <div>
            <img 
              src="/greenhouse-3d.png"
              alt="3D Smart Greenhouse"
              className="w-full"
            />
          </div>
        </div>
      </section>

      {/* FarmCloud Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src="/farmcloud-laptop.png"
              alt="FarmCloud Dashboard"
              className="w-full"
            />
          </div>
          <div>
            <h2 className="text-4xl font-bold mb-6">
              Save time and control your<br />
              farm or Greenhouse activity<br />
              with <span className="text-green-500">Farm</span><span className="text-blue-500">Cloud</span>™
            </h2>
            
            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-bold text-amber-800 mb-2">Digitise your farm records</h3>
                <p className="text-gray-700">
                  Move from files and excel and track all your spraying programs and harvest records on one platform trusted by Buyers and Financiers.
                </p>
              </div>
              
              <div>
                <h3 className="text-xl font-bold text-amber-800 mb-2">Access a marketplace</h3>
                <p className="text-gray-700">
                  Access to instant market for your harvest
                </p>
              </div>
              
              <div>
                <h3 className="text-xl font-bold text-amber-800 mb-2">Get export compliant</h3>
                <p className="text-gray-700">
                  Track farm activities and generate traceability reports for your buyers easily
                </p>
              </div>
            </div>

            <div className="flex gap-4 mt-8">
              <button className={cn(
                "px-6 py-3 bg-green-500 text-white rounded-lg",
                "hover:bg-green-600 transition-colors"
              )}>
                Book a FarmCloud Demo
              </button>
              <a href="#" className="text-green-500 hover:text-green-600 inline-flex items-center transition-colors">
                Learn More <ChevronRight className="h-4 w-4 ml-1" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* FarmShield Section */}
      <section className="bg-green-50 py-20">
        <div className="container mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-bold mb-6">
              Use <span className="text-green-500">Farm</span><span className="text-orange-500">Shield</span>™ to<br />
              Increase efficiency and<br />
              take the guesswork out<br />
              of farm management.
            </h2>
            <p className="text-gray-700 mb-8">
              The FarmShield™ is the brain of the farm and shields the farm from any adverse conditions. It combines data from our trademarked FarmSpears, and checks if anything has exceeded the required levels in the farm and if so, takes the necessary action to correct it.
            </p>
            <div className="flex gap-4">
              <button className={cn(
                "px-6 py-3 bg-green-500 text-white rounded-lg",
                "hover:bg-green-600 transition-colors"
              )}>
                Explore FarmShield
              </button>
              <a href="#" className="text-green-500 hover:text-green-600 inline-flex items-center transition-colors">
                View Pricing <ChevronRight className="h-4 w-4 ml-1" />
              </a>
            </div>
          </div>
          <div>
            <img 
              src="/farmshield-device.png"
              alt="FarmShield Device"
              className="w-full"
            />
          </div>
        </div>
      </section>

      {/* Blog Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-2">
            Learn how to make complex farming<br />
            simple <span className="text-green-500">with the Synnefa Blog</span>
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8 mt-16">
            {/* Blog Post 1 */}
            <div className="bg-white rounded-xl overflow-hidden shadow-lg">
              <img 
                src="https://images.unsplash.com/photo-1560493676-04071c5f467b"
                alt="Farmer in Kenya"
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-3">Synnefa among organisations to receive $1.7m Funding Boost for Innovators</h3>
                <p className="text-gray-600 mb-4">The Efficiency for Access Research and Development Fund has awarded a total of $1.7 million to eleven pioneering organisations, including Nairobi-based Synnefa.</p>
                <div className="text-sm text-gray-500">
                  <span>Taita Ngetich</span>
                  <span> - </span>
                  <span>August 21, 2024</span>
                </div>
              </div>
            </div>

            {/* Blog Post 2 */}
            <div className="bg-white rounded-xl overflow-hidden shadow-lg">
              <img 
                src="https://images.unsplash.com/photo-1515872474884-c6cc5e4c2fe5"
                alt="Herbs and spices"
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-3">10 Types of Herbs to Farm in Kenya, Their Use and Value</h3>
                <p className="text-gray-600 mb-4">Growing herbs can be highly profitable and fun. It's really quite easy too. You'd be surprised how many herbs are available and how many of them are huge sellers for a herb business.</p>
                <div className="text-sm text-gray-500">
                  <span>Janet Machuka and Taita Ngetich</span>
                  <span> - </span>
                  <span>August 21, 2024</span>
                </div>
              </div>
            </div>

            {/* Blog Post 3 */}
            <div className="bg-white rounded-xl overflow-hidden shadow-lg">
              <img 
                src="https://images.unsplash.com/photo-1595665593673-bf1ad72905c0"
                alt="Farmers market"
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-3">10 Ways Farmers can Find Markets for Farm Produce</h3>
                <p className="text-gray-600 mb-4">The market for farm products is growing rapidly and this is good for farmers. However, it can also be overwhelming for a farmer who's trying to sell their product.</p>
                <div className="text-sm text-gray-500">
                  <span>Janet Machuka</span>
                  <span> - </span>
                  <span>August 21, 2024</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-green-900 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-4 gap-8">
            {/* Logo and Social Links */}
            <div>
              <div className="flex items-center gap-2 mb-6">
                <Sprout className="h-8 w-8 text-white" />
                <span className="text-xl font-bold">Synnefa</span>
              </div>
              <div className="flex gap-4">
                <a href="#" className="text-white hover:text-green-300 transition-colors">
                  <Facebook className="h-5 w-5" />
                </a>
                <a href="#" className="text-white hover:text-green-300 transition-colors">
                  <Twitter className="h-5 w-5" />
                </a>
                <a href="#" className="text-white hover:text-green-300 transition-colors">
                  <Linkedin className="h-5 w-5" />
                </a>
                <a href="#" className="text-white hover:text-green-300 transition-colors">
                  <Instagram className="h-5 w-5" />
                </a>
                <a href="#" className="text-white hover:text-green-300 transition-colors">
                  <Youtube className="h-5 w-5" />
                </a>
                <a href="#" className="text-white hover:text-green-300 transition-colors">
                  <Globe className="h-5 w-5" />
                </a>
              </div>
            </div>

            {/* Products */}
            <div>
              <h3 className="font-bold mb-4">Products</h3>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-green-300 transition-colors">FarmCloud</a></li>
                <li><a href="#" className="hover:text-green-300 transition-colors">FarmShield</a></li>
                <li><a href="#" className="hover:text-green-300 transition-colors">Smart Greenhouses</a></li>
                <li><a href="#" className="hover:text-green-300 transition-colors">Smart Solar Dryers</a></li>
                <li><a href="#" className="hover:text-green-300 transition-colors">Screenhouses</a></li>
                <li><a href="#" className="hover:text-green-300 transition-colors">NetHouses</a></li>
                <li><a href="#" className="hover:text-green-300 transition-colors">Smart Drip Kits</a></li>
                <li><a href="#" className="hover:text-green-300 transition-colors">Herbs for Export</a></li>
              </ul>
            </div>

            {/* Resources */}
            <div>
              <h3 className="font-bold mb-4">Resources</h3>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-green-300 transition-colors">About Synnefa</a></li>
                <li><a href="#" className="hover:text-green-300 transition-colors">Farmer Help Centre</a></li>
                <li><a href="#" className="hover:text-green-300 transition-colors">Pricing Calculator</a></li>
                <li><a href="#" className="hover:text-green-300 transition-colors">Request Pre-Site Survey</a></li>
                <li><a href="#" className="hover:text-green-300 transition-colors">Request a Meeting</a></li>
                <li><a href="#" className="hover:text-green-300 transition-colors">Terms & Conditions</a></li>
                <li><a href="#" className="hover:text-green-300 transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-green-300 transition-colors">Press Kit</a></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h3 className="font-bold mb-4">Contact</h3>
              <div className="space-y-4">
                <div>
                  <p className="font-semibold">Synnefa Kenya offices:</p>
                  <p>Postal Address: P.O.BOX 23170-00505, NGONG ROAD, NAIROBI</p>
                  <p>Physical Address: Bishop Magua Centre-4th Floor, Ngong Road,</p>
                  <p>Opposite Uchumi Ngong Hyper.</p>
                </div>
                <div>
                  <p className="font-semibold">Kenya Support Line:</p>
                  <p>+254 20 3892455</p>
                </div>
                <div>
                  <p className="font-semibold">Working Hours (GMT+3):</p>
                  <p>Monday to Friday, 8am – 5pm | Saturdays, 9am – 1pm</p>
                  <p>Closed on Sundays</p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-12 pt-8 border-t border-green-800">
            <p className="text-sm">Copyright © 2014-2025 · Jalmac, Inc.</p>
            <p className="text-sm">All Rights Reserved</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;